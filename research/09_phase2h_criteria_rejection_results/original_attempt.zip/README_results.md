Phase 2H saved experiment. Run completion is separate from task quality, independent criteria review, and numerical acceptance.
Full raw vectors, split/source manifests and locks accompany the compact summary. Features.sqlite files are excluded from the archive but retained in the live runtime.
